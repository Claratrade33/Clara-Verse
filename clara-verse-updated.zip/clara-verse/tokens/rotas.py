from flask import Blueprint, render_template, request, redirect, url_for, flash
from .model import TokenSimbolico

tokens_bp = Blueprint('tokens', __name__)
tokens_registrados = []

@tokens_bp.route('/gerar_token', methods=['GET', 'POST'])
def gerar_token():
    if request.method == 'POST':
        nome = request.form['nome']
        categoria = request.form['categoria']
        descricao = request.form['descricao']
        criador = request.form['criador']

        novo_token = TokenSimbolico(nome, categoria, descricao, criador)
        tokens_registrados.append(novo_token)

        flash(f"Token '{nome}' gerado com sucesso!", "sucesso")
        return redirect(url_for('tokens.lista_tokens'))

    return render_template('tokens/gerar_token.html')

@tokens_bp.route('/tokens_registrados')
def lista_tokens():
    return render_template(
        'tokens/lista_tokens.html',
        tokens=[t.to_dict() for t in tokens_registrados]
    )