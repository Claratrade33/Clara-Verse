# sinais.py

def gerar_sinais(market_data):
    """
    Gera sinais com base nos dados de mercado recebidos.
    Estratégia simples de cruzamento de médias e RSI.
    """
    sinais = []
    
    for ativo, dados in market_data.items():
        preco_atual = dados["preco"]
        rsi = dados["rsi"]
        ma_curta = dados["ma_curta"]
        ma_longa = dados["ma_longa"]

        if rsi < 30 and ma_curta > ma_longa:
            sinais.append({"ativo": ativo, "acao": "compra", "preco": preco_atual})
        elif rsi > 70 and ma_curta < ma_longa:
            sinais.append({"ativo": ativo, "acao": "venda", "preco": preco_atual})

    return sinais