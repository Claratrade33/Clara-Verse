from datetime import datetime

eventos_log = []

def salvar_log(mensagem):
    eventos_log.append({
        "mensagem": mensagem,
        "data": datetime.now().strftime("%d/%m/%Y %H:%M:%S")
    })

def log_evento(limit=10):
    return eventos_log[-limit:]