from flask import Blueprint, render_template, request, redirect, url_for, flash
from .model import MensagemOraculo

oraculo_bp = Blueprint('oraculo', __name__)
mensagens_oraculo = []

@oraculo_bp.route('/nova_mensagem_oraculo', methods=['GET', 'POST'])
def nova_msg():
    if request.method == 'POST':
        titulo = request.form['titulo']
        origem = request.form['origem']
        corpo = request.form['corpo']
        tipo = request.form.get('tipo', 'inspiração')

        nova = MensagemOraculo(titulo, origem, corpo, tipo)
        mensagens_oraculo.append(nova)

        flash("Mensagem do Oráculo enviada!", "sucesso")
        return redirect(url_for('oraculo.lista_mensagens'))

    return render_template('oraculo/nova_msg.html')

@oraculo_bp.route('/oraculo_mensagens')
def lista_mensagens():
    return render_template(
        'oraculo/lista_mensagens.html',
        mensagens=[m.to_dict() for m in mensagens_oraculo]
    )