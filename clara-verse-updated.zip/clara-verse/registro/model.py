# /registro/model.py

import os
import json

CAMINHO_BANCO = 'registro/usuarios.json'

def carregar_usuarios():
    if not os.path.exists(CAMINHO_BANCO):
        return []
    with open(CAMINHO_BANCO, 'r', encoding='utf-8') as f:
        return json.load(f)

def salvar_usuario(nome, email, senha):
    usuarios = carregar_usuarios()

    # Verifica se o e-mail já está cadastrado
    if any(user['email'] == email for user in usuarios):
        return False

    novo_usuario = {
        'nome': nome,
        'email': email,
        'senha': senha  # Em produção: NUNCA salve senhas assim!
    }

    usuarios.append(novo_usuario)

    with open(CAMINHO_BANCO, 'w', encoding='utf-8') as f:
        json.dump(usuarios, f, indent=2, ensure_ascii=False)

    return True