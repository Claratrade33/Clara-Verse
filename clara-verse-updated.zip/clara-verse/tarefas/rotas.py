from flask import Blueprint, jsonify
import threading
import time

tarefas_bp = Blueprint('tarefas', __name__)

# Exemplo de ciclo de verificação de mercado
def verificar_mercado():
    print("⏳ Iniciando verificação do mercado...")
    for i in range(3):
        print(f"🔁 Verificação {i+1}/3 em andamento...")
        time.sleep(1)
    print("✅ Verificação de mercado finalizada.")

@tarefas_bp.route('/tarefas/iniciar_verificacao', methods=['GET'])
def iniciar_verificacao():
    thread = threading.Thread(target=verificar_mercado)
    thread.start()
    return jsonify({"status": "em andamento", "mensagem": "Verificação iniciada em segundo plano."})