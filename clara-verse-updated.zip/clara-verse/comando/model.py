from datetime import datetime

class Comando:
    def __init__(self, nome, status):
        self.nome = nome                  # Ex: "entrar", "sair", "pausar", "reverter", "emergência"
        self.status = status              # ativo / inativo
        self.data_execucao = datetime.now()

    def to_dict(self):
        return {
            "nome": self.nome,
            "status": self.status,
            "data_execucao": self.data_execucao.strftime('%d/%m/%Y %H:%M')
        }