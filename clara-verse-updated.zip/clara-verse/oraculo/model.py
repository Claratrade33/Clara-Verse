from datetime import datetime
import uuid

class MensagemOraculo:
    def __init__(self, titulo, origem, corpo, tipo="inspiração"):
        self.id = str(uuid.uuid4())[:8]
        self.titulo = titulo
        self.origem = origem            # clarinha, sistema, manual, outro
        self.corpo = corpo
        self.tipo = tipo                # inspiração, alerta, instrução, profecia
        self.data_envio = datetime.now()

    def to_dict(self):
        return {
            "id": self.id,
            "titulo": self.titulo,
            "origem": self.origem,
            "corpo": self.corpo,
            "tipo": self.tipo,
            "data_envio": self.data_envio.strftime('%d/%m/%Y %H:%M')
        }