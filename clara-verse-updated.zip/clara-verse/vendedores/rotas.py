from flask import Blueprint, render_template

vendedores_bp = Blueprint('vendedores', __name__)

@vendedores_bp.route('/painel_vendedores')
def painel_vendedores():
    return render_template('vendedores/painel_vendedores.html')