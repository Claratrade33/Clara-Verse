# Lista temporária de clientes (simulando um banco de dados)
clientes = []

def listar_clientes():
    return clientes

def salvar_cliente(nome, email, plano, token):
    cliente = {
        "nome": nome,
        "email": email,
        "plano": plano,
        "token": token
    }
    clientes.append(cliente)