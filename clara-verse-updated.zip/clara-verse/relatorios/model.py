from datetime import datetime
import uuid

class Relatorio:
    def __init__(self, titulo, categoria, conteudo, autor="clarinha"):
        self.id = str(uuid.uuid4())[:8]
        self.titulo = titulo
        self.categoria = categoria        # exemplo: operações, finanças, sinais, espiritual
        self.conteudo = conteudo
        self.autor = autor
        self.data_criacao = datetime.now()

    def to_dict(self):
        return {
            "id": self.id,
            "titulo": self.titulo,
            "categoria": self.categoria,
            "conteudo": self.conteudo,
            "autor": self.autor,
            "data_criacao": self.data_criacao.strftime('%d/%m/%Y %H:%M')
        }
