from flask import Blueprint, request, render_template, redirect, url_for, flash
from .model import Usuario

usuarios_bp = Blueprint('usuarios', __name__)
usuarios = []

@usuarios_bp.route('/cadastro', methods=['GET', 'POST'])
def cadastro():
    if request.method == 'POST':
        nome_completo = request.form['nome_completo']
        nascimento = request.form['nascimento']
        telefone = request.form['telefone']
        email = request.form['email']
        usuario = request.form['usuario']
        senha = request.form['senha']

        novo_usuario = Usuario(nome_completo, nascimento, telefone, email, usuario, senha)
        usuarios.append(novo_usuario)

        flash(f"Usuário {usuario} cadastrado com sucesso!", "sucesso")
        return redirect(url_for('usuarios.lista_usuarios'))

    return render_template('registro/cadastro_usuario.html')

@usuarios_bp.route('/usuarios')
def lista_usuarios():
    return render_template('registro/lista_usuarios.html', usuarios=[u.to_dict() for u in usuarios])