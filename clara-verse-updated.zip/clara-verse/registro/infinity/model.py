from datetime import datetime
import uuid

class TokenInfinity:
    def __init__(self, criador, tipo='usuario'):
        self.criador = criador  # pode ser usuário ou anjo
        self.tipo = tipo        # 'usuario' ou 'anjo'
        self.token = self.gerar_token()
        self.data_geracao = datetime.now()

    def gerar_token(self):
        prefixo = 'infinity'
        base = f"{self.tipo}/{self.criador.lower()}-{str(uuid.uuid4())[:8]}"
        return f"{prefixo}/{base}"

    def to_dict(self):
        return {
            "criador": self.criador,
            "tipo": self.tipo,
            "token": self.token,
            "data_geracao": self.data_geracao.isoformat()
        }