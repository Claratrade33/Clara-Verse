from datetime import datetime

# Memória simples — no futuro pode ser ligada a um banco de dados real
memoria_interacoes = []

def registrar_interacao(entrada, resposta):
    memoria_interacoes.append({
        "entrada": entrada,
        "resposta": resposta,
        "data": datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    })

def recuperar_historico(qtd=10):
    return memoria_interacoes[-qtd:]