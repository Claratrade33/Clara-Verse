def verificar_limite_operacao(banca_total, valor_operacao, limite_percentual=5.0):
    """
    Verifica se o valor da operação está dentro do limite permitido da banca.
    """
    limite_maximo = banca_total * (limite_percentual / 100)
    return valor_operacao <= limite_maximo