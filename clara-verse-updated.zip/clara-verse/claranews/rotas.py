from flask import Blueprint, render_template, request, redirect, url_for, flash
from datetime import datetime

claranews_bp = Blueprint('claranews', __name__)

# Lista temporária de notícias (substituir futuramente por banco de dados)
noticias = []

@claranews_bp.route('/claranews/nova', methods=['GET', 'POST'])
def nova_noticia():
    if request.method == 'POST':
        titulo = request.form.get('titulo')
        conteudo = request.form.get('conteudo')
        fonte = request.form.get('fonte')
        data_publicacao = datetime.now().strftime('%d/%m/%Y %H:%M')

        nova = {
            'titulo': titulo,
            'conteudo': conteudo,
            'fonte': fonte,
            'data': data_publicacao
        }

        noticias.append(nova)
        flash('Notícia adicionada com sucesso!', 'success')
        return redirect(url_for('claranews.lista_noticias'))

    return render_template('claranews/nova_noticia.html')


@claranews_bp.route('/claranews/lista')
def lista_noticias():
    return render_template('claranews/lista_noticias.html', noticias=noticias)


@claranews_bp.route('/claranews/<int:indice>')
def noticias(indice):
    if 0 <= indice < len(noticias):
        noticia = noticias[indice]
        return render_template('claranews/noticias.html', noticia=noticia)
    else:
        flash('Notícia não encontrada.', 'danger')
        return redirect(url_for('claranews.lista_noticias'))