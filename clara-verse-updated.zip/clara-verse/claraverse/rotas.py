from flask import Blueprint, render_template

claraverse_bp = Blueprint('claraverse', __name__)

@claraverse_bp.route('/claraverse/pegadas')
def pegadas_do_cerrado():
    return render_template('claraverse/pegadas_do_cerrado.html')