from datetime import datetime

class Feedback:
    def __init__(self, id, usuario, tipo, mensagem, token, data=None):
        self.id = id
        self.usuario = usuario
        self.tipo = tipo
        self.mensagem = mensagem
        self.token = token
        self.data = data or datetime.now().strftime('%d/%m/%Y %H:%M:%S')