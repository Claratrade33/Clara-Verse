import requests

def testar_conexao_binance(api_key, api_secret):
    try:
        response = requests.get('https://api.binance.com/api/v3/account', headers={
            'X-MBX-APIKEY': api_key
        })
        return response.status_code == 200
    except Exception:
        return False

def testar_conexao_openai(api_key):
    try:
        headers = {
            'Authorization': f'Bearer {api_key}'
        }
        response = requests.get('https://api.openai.com/v1/models', headers=headers)
        return response.status_code == 200
    except Exception:
        return False

def testar_conexao_coinmarketcap(api_key):
    try:
        headers = {
            'X-CMC_PRO_API_KEY': api_key
        }
        response = requests.get('https://pro-api.coinmarketcap.com/v1/cryptocurrency/map', headers=headers)
        return response.status_code == 200
    except Exception:
        return False