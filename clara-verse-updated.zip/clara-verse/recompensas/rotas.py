from flask import Blueprint, render_template, request, redirect, url_for, flash
from .model import listar_recompensas, adicionar_recompensa
from .utils import calcular_pontos

recompensas_bp = Blueprint('recompensas', __name__)

@recompensas_bp.route('/recompensas')
def painel_recompensas():
    recompensas = listar_recompensas()
    return render_template('recompensas/painel_recompensas.html', recompensas=recompensas)

@recompensas_bp.route('/recompensas/nova', methods=['GET', 'POST'])
def nova_recompensa():
    if request.method == 'POST':
        titulo = request.form['titulo']
        descricao = request.form['descricao']
        pontos = int(request.form['pontos'])

        adicionar_recompensa(titulo, descricao, pontos)
        flash('Recompensa adicionada com sucesso!', 'success')
        return redirect(url_for('recompensas.painel_recompensas'))

    return render_template('recompensas/nova_recompensa.html')