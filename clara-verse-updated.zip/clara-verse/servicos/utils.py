import requests
import datetime

def testar_api_externa(url):
    try:
        resposta = requests.get(url, timeout=5)
        return resposta.status_code == 200
    except:
        return False

def registrar_log_servico(servico, mensagem):
    agora = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    log = f"[{agora}] [{servico.upper()}] {mensagem}\n"
    with open("logs_servicos.txt", "a") as arquivo_log:
        arquivo_log.write(log)

def enviar_alerta(mensagem, canal="sistema"):
    print(f"[ALERTA:{canal.upper()}] {mensagem}")
    # Aqui você pode implementar envio real: email, Telegram, Discord, etc.