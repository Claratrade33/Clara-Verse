"""Funções utilitárias para o módulo de inteligência financeira.

Este módulo contém funções auxiliares usadas pelas rotas de
inteligência financeira. Incluem, por exemplo, utilitários
para converter dados em formatos adequados para envio ao modelo
de linguagem e validação de parâmetros fornecidos pelo usuário.
"""

from __future__ import annotations

import pandas as pd


def df_to_markdown_table(df: pd.DataFrame) -> str:
    """Converte um DataFrame em uma representação de tabela em Markdown.

    A biblioteca da OpenAI lida melhor com texto formatado em vez de
    objetos Python nativos. Transformar dados de mercado em tabela
    Markdown ajuda o modelo a entender padrões e tendências.

    Args:
        df: DataFrame contendo colunas de interesse, como datas e preços.

    Returns:
        Uma string formatada em Markdown representando a tabela.
    """
    if df.empty:
        return "(sem dados)"
    # Seleciona as cinco últimas entradas para evitar mensagens muito longas
    subset = df.tail(5).copy()
    markdown = "| Data | Preço de Fechamento |\n|---|---|\n"
    for _, row in subset.iterrows():
        markdown += f"| {row['open_time'].strftime('%Y-%m-%d %H:%M')} | {row['close']:.2f} |\n"
    return markdown