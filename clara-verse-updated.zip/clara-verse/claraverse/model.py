PEGADAS_DO_CERRADO = [
    "Operar com consciência, respeitando os ciclos do mercado.",
    "Proteger a banca antes de pensar em multiplicá-la.",
    "Nunca investir o que não pode perder.",
    "Registrar cada aprendizado para evoluir com clareza.",
    "Honrar quem chegou até aqui sem esquecer de onde veio.",
    "Ser luz para outros traders iniciantes.",
    "Transformar lucro em propósito.",
    "Caminhar com humildade, mesmo em meio à vitória."
]