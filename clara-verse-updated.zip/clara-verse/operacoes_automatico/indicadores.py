import pandas as pd

def calcular_rsi(df, periodo=14):
    delta = df['close'].diff()
    ganho = (delta.where(delta > 0, 0)).rolling(window=periodo).mean()
    perda = (-delta.where(delta < 0, 0)).rolling(window=periodo).mean()
    rs = ganho / perda
    rsi = 100 - (100 / (1 + rs))
    return rsi

def calcular_moving_averages(df, short=9, long=21):
    df['MA_Short'] = df['close'].rolling(window=short).mean()
    df['MA_Long'] = df['close'].rolling(window=long).mean()
    return df

def calcular_macd(df):
    exp1 = df['close'].ewm(span=12, adjust=False).mean()
    exp2 = df['close'].ewm(span=26, adjust=False).mean()
    df['MACD'] = exp1 - exp2
    df['Signal'] = df['MACD'].ewm(span=9, adjust=False).mean()
    return df