from flask import Blueprint, render_template
from registro.model import Usuario

infinity_bp = Blueprint('infinity', __name__)

# Exemplo temporário (na prática, importar de base real)
usuarios_exemplo = [
    Usuario("Alice Costa", "1990-01-01", "11999999999", "alice@email.com", "alice", "senha123", "teste"),
    Usuario("Bruno Lima", "1988-07-12", "11988888888", "bruno@email.com", "bruno", "senha456", "pre-inauguracao")
]

@infinity_bp.route('/infinity')
def lista_infinity():
    ids = [u.to_dict() for u in usuarios_exemplo]
    return render_template('infinity/lista_infinity.html', ids=ids)