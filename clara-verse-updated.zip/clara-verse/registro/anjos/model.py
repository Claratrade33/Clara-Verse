from datetime import datetime
import uuid

class Anjo:
    def __init__(self, nome, email, mestre_usuario, funcao, permissao_total=False, comissao=0):
        self.nome = nome
        self.email = email
        self.mestre_usuario = mestre_usuario  # o dono que cadastrou o anjo
        self.funcao = funcao                  # ex: operador, observador, trader
        self.permissao_total = permissao_total
        self.comissao = comissao              # percentual de comissão sobre as ordens
        self.data_cadastro = datetime.now()
        self.token_angelical = self.gerar_token_angelical()

    def gerar_token_angelical(self):
        base = f"{self.mestre_usuario.lower()}-{str(uuid.uuid4())[:8]}"
        return f"anjo/{base}"

    def to_dict(self):
        return {
            "nome": self.nome,
            "email": self.email,
            "mestre_usuario": self.mestre_usuario,
            "funcao": self.funcao,
            "permissao_total": self.permissao_total,
            "comissao": self.comissao,
            "data_cadastro": self.data_cadastro.isoformat(),
            "token_angelical": self.token_angelical
        }