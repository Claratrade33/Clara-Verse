from flask import Blueprint, render_template, request, redirect
from .utils import exportar_dados_financeiros, gerar_sugestoes_clarinha, verificar_alertas

financeiro_bp = Blueprint('financeiro', __name__)

# Dados de exemplo (substituir por banco depois)
dados_financeiros = [
    {"data": "2025-07-01", "tipo": "entrada", "valor": 300},
    {"data": "2025-07-03", "tipo": "gasto", "valor": 120},
    {"data": "2025-07-05", "tipo": "entrada", "valor": 200},
]

@financeiro_bp.route('/financeiro')
def painel_financeiro():
    saldo = sum([d["valor"] if d["tipo"] == "entrada" else -d["valor"] for d in dados_financeiros])
    despesas = sum([d["valor"] for d in dados_financeiros if d["tipo"] == "gasto"])
    sugestoes = gerar_sugestoes_clarinha(saldo, despesas)
    alertas = verificar_alertas(saldo, despesas, limite_previsto=250)

    return render_template('financeiro/painel_financeiro.html',
                           dados=dados_financeiros,
                           saldo=saldo,
                           sugestoes=sugestoes,
                           alertas=alertas)

@financeiro_bp.route('/financeiro/exportar/<formato>')
def exportar_financeiro(formato):
    return exportar_dados_financeiros(dados_financeiros, formato)