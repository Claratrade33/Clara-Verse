# model.py - Estrutura base de dados para vendedores (simulação)

class Vendedor:
    def __init__(self, id, nome, email, comissao):
        self.id = id
        self.nome = nome
        self.email = email
        self.comissao = comissao