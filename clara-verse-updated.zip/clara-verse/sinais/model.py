from flask import Blueprint, render_template, request, redirect, url_for, flash
from datetime import datetime

sinais_bp = Blueprint('sinais', __name__, template_folder='../templates/sinais')

# Lista de sinais simulada
sinais_recebidos = []

@sinais_bp.route('/sinais', methods=['GET', 'POST'])
def painel_sinais():
    if request.method == 'POST':
        origem = request.form['origem']
        tipo = request.form['tipo']
        ativo = request.form['ativo']
        direcao = request.form['direcao']
        forca = request.form['forca']

        novo_sinal = {
            'origem': origem,
            'tipo': tipo,
            'ativo': ativo,
            'direcao': direcao,
            'forca': forca,
            'data_hora': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }

        sinais_recebidos.append(novo_sinal)
        flash('Sinal registrado com sucesso!')
        return redirect(url_for('sinais.painel_sinais'))

    return render_template('sinais/painel_sinais.html', sinais=sinais_recebidos)