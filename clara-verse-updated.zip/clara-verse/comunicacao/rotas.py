from flask import Blueprint, render_template, request, redirect, url_for, flash
import datetime

comunicacao_bp = Blueprint('comunicacao', __name__)

# Simulação de mensagens (substituir por banco de dados futuramente)
mensagens = []

@comunicacao_bp.route('/painel-comunicacao', methods=['GET', 'POST'])
def painel_comunicacao():
    if request.method == 'POST':
        autor = request.form['autor']
        conteudo = request.form['conteudo']
        timestamp = datetime.datetime.now().strftime('%d/%m/%Y %H:%M')

        nova_msg = {
            'autor': autor,
            'conteudo': conteudo,
            'data': timestamp
        }

        mensagens.append(nova_msg)
        flash('Mensagem enviada com sucesso!', 'success')
        return redirect(url_for('comunicacao.painel_comunicacao'))

    return render_template('comunicacao/painel_comunicacao.html', mensagens=mensagens)