from flask import Blueprint, render_template, request, redirect, url_for, flash
from datetime import datetime

comando_bp = Blueprint('comando', __name__, template_folder='../templates/comando')

# Lista simulada de comandos recebidos
comandos_recebidos = []

@comando_bp.route('/comando', methods=['GET', 'POST'])
def comando():
    if request.method == 'POST':
        tipo = request.form.get('tipo')
        descricao = request.form.get('descricao')
        usuario = request.form.get('usuario')

        novo_comando = {
            'tipo': tipo,
            'descricao': descricao,
            'usuario': usuario,
            'data_hora': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }

        comandos_recebidos.append(novo_comando)
        flash('Comando enviado com sucesso!')
        return redirect(url_for('comando.comando'))

    return render_template('comando/painel_comando.html', comandos=comandos_recebidos)

# Rota de API para execução via botão do painel
@comando_bp.route('/api/comando/<acao>')
def executar_comando_api(acao):
    if acao == "ativar_ia":
        return "IA ativada com sucesso!"
    elif acao == "desligar_ia":
        return "IA desligada."
    elif acao == "recarregar_servicos":
        return "Serviços recarregados com sucesso."
    elif acao == "recarregar_tarefas":
        return "Tarefas recarregadas com sucesso."
    elif acao == "verificar_status":
        return "ClaraTrade está online e operante."
    else:
        return f"Comando '{acao}' não reconhecido.", 400