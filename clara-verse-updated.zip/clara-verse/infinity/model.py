from datetime import datetime
import uuid

class InfinityID:
    def __init__(self, usuario, origem, descricao):
        self.id = str(uuid.uuid4())[:8]
        self.usuario = usuario
        self.origem = origem  # Ex: ClareGrão, Convocação, Código de Luz
        self.descricao = descricao
        self.infinity_token = f"infinity/{usuario.lower()}"
        self.data_criacao = datetime.now()

    def to_dict(self):
        return {
            "id": self.id,
            "usuario": self.usuario,
            "origem": self.origem,
            "descricao": self.descricao,
            "infinity_token": self.infinity_token,
            "data_criacao": self.data_criacao.strftime('%d/%m/%Y %H:%M')
        }