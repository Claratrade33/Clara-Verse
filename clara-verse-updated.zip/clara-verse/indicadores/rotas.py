from flask import Blueprint, render_template, request
from .utils import calcular_indicadores, comparar_indicadores
from .model import INDICADORES_DISPONIVEIS

indicadores_bp = Blueprint('indicadores', __name__)

@indicadores_bp.route('/indicadores')
def painel_indicadores():
    return render_template('indicadores/painel_indicadores.html', indicadores=INDICADORES_DISPONIVEIS)

@indicadores_bp.route('/indicadores/<nome>')
def detalhe_indicador(nome):
    resultado = calcular_indicadores(nome)
    return render_template('indicadores/detalhe_indicador.html', nome=nome, resultado=resultado)

@indicadores_bp.route('/indicadores/comparar', methods=['GET', 'POST'])
def comparar():
    if request.method == 'POST':
        ind1 = request.form['indicador1']
        ind2 = request.form['indicador2']
        comparacao = comparar_indicadores(ind1, ind2)
        return render_template('indicadores/comparar_indicadores.html', comparacao=comparacao, ind1=ind1, ind2=ind2)
    return render_template('indicadores/comparar_indicadores.html')