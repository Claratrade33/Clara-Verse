class Configuracao:
    def __init__(self, modo_operacao, estrategia, intervalo_candle, risco_percentual, api_binance=None, api_openai=None):
        self.modo_operacao = modo_operacao                  # manual, semi-automatico, automatico
        self.estrategia = estrategia                        # ex: cruzamento de médias, rsi, volume, IA híbrida
        self.intervalo_candle = intervalo_candle            # ex: 1m, 5m, 15m
        self.risco_percentual = risco_percentual            # percentual do capital a ser usado
        self.api_binance = api_binance                      # chave (opcional, segura)
        self.api_openai = api_openai                        # chave (opcional, segura)

    def to_dict(self):
        return {
            "modo_operacao": self.modo_operacao,
            "estrategia": self.estrategia,
            "intervalo_candle": self.intervalo_candle,
            "risco_percentual": self.risco_percentual,
            "api_binance": "••••••" if self.api_binance else "",
            "api_openai": "••••••" if self.api_openai else ""
        }