# Futuro modelo de estatísticas gerais (pode usar banco de dados depois)

def coletar_estatisticas():
    return {
        'usuarios': 0,
        'sinais_emitidos': 0,
        'operacoes_executadas': 0,
        'lucro_total': 0.0,
        'anjos_ativos': 0,
        'tokens_ativos': 0
    }