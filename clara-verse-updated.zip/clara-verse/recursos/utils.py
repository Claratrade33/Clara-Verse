def calcular_resultado(valor1, valor2, operacao):
    try:
        if operacao == 'soma':
            return valor1 + valor2
        elif operacao == 'subtracao':
            return valor1 - valor2
        elif operacao == 'multiplicacao':
            return valor1 * valor2
        elif operacao == 'divisao':
            return valor1 / valor2 if valor2 != 0 else 'Erro: divisão por zero'
        else:
            return 'Operação inválida'
    except Exception as e:
        return f'Erro: {str(e)}'

def converter_valor(valor, tipo):
    try:
        if tipo == 'usd_brl':
            return valor * 5.2
        elif tipo == 'brl_usd':
            return valor / 5.2
        elif tipo == 'btc_usd':
            return valor * 30000
        elif tipo == 'usd_btc':
            return valor / 30000
        else:
            return 'Conversão inválida'
    except Exception as e:
        return f'Erro: {str(e)}'