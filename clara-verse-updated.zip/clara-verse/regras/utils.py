def validar_regra(nome, condicao, acao):
    return all([nome.strip(), condicao.strip(), acao.strip()])