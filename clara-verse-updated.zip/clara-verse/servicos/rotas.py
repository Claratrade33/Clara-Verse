from flask import Blueprint, jsonify, request

servicos_bp = Blueprint('servicos', __name__)

# Serviço: Verificação de status da API externa
@servicos_bp.route('/servicos/status_api', methods=['GET'])
def status_api():
    # Exemplo de verificação (você pode trocar isso pela Binance, OpenAI etc.)
    try:
        # Aqui pode colocar verificação real como ping a uma API
        return jsonify({"status": "online", "mensagem": "API funcionando corretamente."}), 200
    except Exception as e:
        return jsonify({"status": "erro", "mensagem": str(e)}), 500

# Serviço: Receber webhooks
@servicos_bp.route('/servicos/webhook', methods=['POST'])
def receber_webhook():
    dados = request.json
    # Aqui você pode tratar comandos recebidos de outro sistema externo
    print("Webhook recebido:", dados)
    return jsonify({"status": "sucesso", "mensagem": "Webhook recebido com sucesso!"}), 200

# Serviço: Consulta geral de saúde dos serviços
@servicos_bp.route('/servicos/healthcheck', methods=['GET'])
def health_check():
    return jsonify({
        "servico": "ClaraTrade",
        "status": "ativo",
        "versao": "1.0.0"
    }), 200