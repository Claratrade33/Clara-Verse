def obter_noticias_financeiras():
    # Simulando retorno de API (substituir depois por integração real)
    return [
        {
            "titulo": "Bitcoin rompe resistência dos US$ 70 mil",
            "fonte": "Binance News",
            "link": "https://www.binance.com/pt/news",
            "data": "2025-07-12"
        },
        {
            "titulo": "B3 fecha em alta após decisão do Copom",
            "fonte": "Valor Econômico",
            "link": "https://valor.globo.com",
            "data": "2025-07-12"
        },
        {
            "titulo": "Ethereum sobe 5% com otimismo sobre ETFs",
            "fonte": "CoinTelegraph",
            "link": "https://cointelegraph.com",
            "data": "2025-07-12"
        }
    ]