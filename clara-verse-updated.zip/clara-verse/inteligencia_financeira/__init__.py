"""Módulo de inteligência financeira.

Este pacote fornece funcionalidades para gerar análises de mercado
utilizando dados da Binance e modelos da OpenAI. Ele expõe um
Blueprint do Flask que renderiza um formulário simples para o
usuário solicitar uma análise e, em seguida, retorna um resumo
gerado por IA. As chaves de API são lidas das variáveis de
ambiente definidas no arquivo `.env`.

Crie novos arquivos ou expanda este módulo conforme necessário
para adicionar mais rotas ou utilidades relacionadas à inteligência
financeira.
"""

from .rotas import inteligencia_bp  # noqa: F401