def obter_dados_financeiros():
    # Exemplo fictício; em produção, conectar ao banco real
    return [
        {"data": "2025-07-01", "tipo": "entrada", "descricao": "Lucro operação BTC", "valor": 1200},
        {"data": "2025-07-02", "tipo": "saida", "descricao": "Compra de API", "valor": 100},
        {"data": "2025-07-03", "tipo": "entrada", "descricao": "Venda pacote ClaraStore", "valor": 450},
        {"data": "2025-07-04", "tipo": "saida", "descricao": "Comissão vendedor", "valor": 50},
    ]