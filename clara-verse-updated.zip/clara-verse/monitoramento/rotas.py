from flask import Blueprint, render_template, jsonify
from .model import obter_status_sistema, listar_tokens_ativos, desempenho_bots
from .utils import verificar_memoria, log_requisicoes_externas

monitoramento_bp = Blueprint('monitoramento', __name__)

@monitoramento_bp.route('/monitoramento')
def painel_monitoramento():
    status = obter_status_sistema()
    tokens = listar_tokens_ativos()
    memoria = verificar_memoria()
    requisicoes = log_requisicoes_externas()
    return render_template('monitoramento/painel_monitoramento.html',
                           status=status,
                           tokens=tokens,
                           memoria=memoria,
                           requisicoes=requisicoes)

@monitoramento_bp.route('/monitoramento/token/<token_id>')
def detalhe_token(token_id):
    tokens = listar_tokens_ativos()
    token_info = next((t for t in tokens if t['id'] == token_id), None)
    return render_template('monitoramento/detalhe_token.html', token=token_info)

@monitoramento_bp.route('/monitoramento/bots')
def status_bots():
    bots = desempenho_bots()
    return render_template('monitoramento/status_bots.html', bots=bots)