from flask import Blueprint, request, render_template, redirect, url_for, flash
from .model import OrdemManual

ordens_manual_bp = Blueprint('ordens_manual', __name__)
ordens = []

@ordens_manual_bp.route('/nova_ordem', methods=['GET', 'POST'])
def nova_ordem():
    if request.method == 'POST':
        ativo = request.form['ativo']
        tipo_ordem = request.form['tipo_ordem']
        quantidade = request.form['quantidade']
        preco = request.form['preco']
        usuario = request.form['usuario']

        nova = OrdemManual(ativo, tipo_ordem, quantidade, preco, usuario)
        ordens.append(nova)

        flash(f"Ordem de {tipo_ordem} para {ativo} registrada com sucesso!", "sucesso")
        return redirect(url_for('ordens_manual.lista_ordens'))

    return render_template('operacoes/manual/nova_ordem.html')

@ordens_manual_bp.route('/ordens')
def lista_ordens():
    return render_template('operacoes/manual/lista_ordens.html', ordens=[o.to_dict() for o in ordens])