from datetime import datetime
import uuid

class TokenSimbolico:
    def __init__(self, nome, categoria, descricao, criador):
        self.id = str(uuid.uuid4())[:8]
        self.nome = nome
        self.categoria = categoria  # Ex: claregrao, runa, chave, fragmento
        self.descricao = descricao
        self.criador = criador
        self.data_criacao = datetime.now()

    def to_dict(self):
        return {
            "id": self.id,
            "nome": self.nome,
            "categoria": self.categoria,
            "descricao": self.descricao,
            "criador": self.criador,
            "data_criacao": self.data_criacao.strftime('%d/%m/%Y %H:%M')
        }