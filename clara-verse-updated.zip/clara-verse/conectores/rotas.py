from flask import Blueprint, render_template, request, redirect, url_for, flash
import os
from dotenv import load_dotenv

conectores_bp = Blueprint('conectores', __name__)
load_dotenv()

@conectores_bp.route('/conectores')
def painel_conectores():
    return render_template('conectores/painel_conectores.html')

@conectores_bp.route('/conectores/configurar-api', methods=['GET', 'POST'])
def configurar_api():
    if request.method == 'POST':
        nova_key = request.form.get('api_key')
        nova_secret = request.form.get('api_secret')

        if nova_key and nova_secret:
            with open('.env', 'w') as env_file:
                env_file.write(f"BINANCE_API_KEY={nova_key}\n")
                env_file.write(f"BINANCE_API_SECRET={nova_secret}\n")
                env_file.write("BINANCE_BASE_URL=https://api.binance.com\n")
            flash('Chaves atualizadas com sucesso.', 'success')
            return redirect(url_for('conectores.painel_conectores'))
        else:
            flash('Preencha os dois campos.', 'danger')

    return render_template('conectores/configurar_api.html')