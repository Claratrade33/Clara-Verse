import os

def salvar_arquivo(arquivo, nome_arquivo):
    pasta_destino = 'static/documentos'
    os.makedirs(pasta_destino, exist_ok=True)
    caminho = os.path.join(pasta_destino, nome_arquivo)
    arquivo.save(caminho)
    return caminho