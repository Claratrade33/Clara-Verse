from .indicadores import calcular_rsi, calcular_macd, calcular_moving_averages
from .leitura_mercado import obter_dados_binance

def gerar_sugestao_operacao(symbol='BTCUSDT'):
    df = obter_dados_binance(symbol)
    df['RSI'] = calcular_rsi(df)
    df = calcular_macd(df)
    df = calcular_moving_averages(df)

    ultima = df.iloc[-1]
    sugestao = {
        "moeda": symbol,
        "RSI": ultima['RSI'],
        "MACD": ultima['MACD'],
        "Signal": ultima['Signal'],
        "MA_Short": ultima['MA_Short'],
        "MA_Long": ultima['MA_Long'],
        "acao": "COMPRA" if ultima['RSI'] < 30 and ultima['MACD'] > ultima['Signal'] else "VENDA" if ultima['RSI'] > 70 else "AGUARDAR"
    }
    return sugestao