treinamentos_db = []

def obter_treinamentos():
    return treinamentos_db

def salvar_treinamento(treinamento):
    treinamentos_db.append(treinamento)

def obter_treinamento_por_id(treinamento_id):
    for treinamento in treinamentos_db:
        if treinamento['id'] == treinamento_id:
            return treinamento
    return None