# Simulação de banco de dados de usuários
usuarios = [
    {
        'id': 1,
        'nome': 'Administrador',
        'email': 'admin@claratrade.com',
        'senha': 'admin123'  # Em produção, nunca armazene senhas em texto plano
    },
    {
        'id': 2,
        'nome': 'Usuário Teste',
        'email': 'teste@claratrade.com',
        'senha': 'teste123'
    }
]

def obter_usuario_por_email(email):
    for usuario in usuarios:
        if usuario['email'] == email:
            return usuario
    return None