INDICADORES_DISPONIVEIS = [
    "RSI",
    "MACD",
    "Média Móvel Simples",
    "Média Móvel Exponencial",
    "Bollinger Bands",
    "Estocástico",
    "Volume",
    "Índice de Força Relativa",
    "ADX",
    "OBV",
    "Momentum",
    "ATR",
]