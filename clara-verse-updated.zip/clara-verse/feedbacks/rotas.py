from flask import Blueprint, render_template, request, redirect, url_for, flash
from feedbacks.model import Feedback
from feedbacks.utils import salvar_feedback, listar_feedbacks, buscar_feedback_por_id

feedbacks_bp = Blueprint('feedbacks', __name__, template_folder='../templates/feedbacks')

@feedbacks_bp.route('/feedbacks')
def painel_feedbacks():
    lista = listar_feedbacks()
    return render_template('feedbacks/painel_feedbacks.html', feedbacks=lista)

@feedbacks_bp.route('/feedbacks/novo', methods=['GET', 'POST'])
def novo_feedback():
    if request.method == 'POST':
        usuario = request.form.get('usuario')
        tipo = request.form.get('tipo')
        mensagem = request.form.get('mensagem')
        token = request.form.get('token')
        salvar_feedback(usuario, tipo, mensagem, token)
        flash('Feedback enviado com sucesso!', 'success')
        return redirect(url_for('feedbacks.painel_feedbacks'))
    return render_template('feedbacks/novo_feedback.html')

@feedbacks_bp.route('/feedbacks/<int:id>')
def detalhe_feedback(id):
    feedback = buscar_feedback_por_id(id)
    if not feedback:
        flash('Feedback não encontrado.', 'error')
        return redirect(url_for('feedbacks.painel_feedbacks'))
    return render_template('feedbacks/detalhe_feedback.html', feedback=feedback)