from flask_wtf import FlaskForm
from wtforms import StringField, DecimalField, SelectField, SubmitField
from wtforms.validators import DataRequired

class OrdemManualForm(FlaskForm):
    ativo = StringField('Ativo', validators=[DataRequired()])
    tipo_ordem = SelectField('Tipo', choices=[('compra', 'Compra'), ('venda', 'Venda')], validators=[DataRequired()])
    preco_entrada = DecimalField('Preço de Entrada', validators=[DataRequired()])
    take_profit = DecimalField('Take Profit', validators=[DataRequired()])
    stop_loss = DecimalField('Stop Loss', validators=[DataRequired()])
    submit = SubmitField('Enviar Ordem')