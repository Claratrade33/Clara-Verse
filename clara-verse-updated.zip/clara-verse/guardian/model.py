# guardian_model.py

from datetime import datetime

class GuardianAlerta:
    def __init__(self, tipo, mensagem, data=None):
        self.tipo = tipo  # Ex: "Erro", "Aviso", "Execução"
        self.mensagem = mensagem
        self.data = data or datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    def to_dict(self):
        return {
            "tipo": self.tipo,
            "mensagem": self.mensagem,
            "data": self.data
        }

# Lista temporária de alertas (substituir por base de dados depois)
alertas_guardian = []

def adicionar_alerta(tipo, mensagem):
    alerta = GuardianAlerta(tipo, mensagem)
    alertas_guardian.append(alerta)

def listar_alertas():
    return [a.to_dict() for a in alertas_guardian]