from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from acessos.utils import verificar_credenciais
from acessos.model import obter_usuario_por_email

acessos_bp = Blueprint('acessos', __name__)

@acessos_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        senha = request.form['senha']

        usuario = obter_usuario_por_email(email)
        if usuario and verificar_credenciais(usuario, senha):
            session['usuario_id'] = usuario['id']
            session['nome_usuario'] = usuario['nome']
            flash('Login realizado com sucesso!', 'sucesso')
            return redirect(url_for('painel.painel_principal'))
        else:
            flash('Credenciais inválidas. Tente novamente.', 'erro')

    return render_template('acessos/login.html')

@acessos_bp.route('/logout')
def logout():
    session.clear()
    flash('Logout realizado com sucesso.', 'info')
    return redirect(url_for('acessos.login'))

@acessos_bp.route('/painel-acessos')
def painel_acessos():
    if 'usuario_id' not in session:
        return redirect(url_for('acessos.login'))
    return render_template('acessos/painel_acessos.html')

@acessos_bp.route('/controle-acessos')
def controle_acessos():
    if 'usuario_id' not in session:
        return redirect(url_for('acessos.login'))
    return render_template('acessos/controle_acessos.html')