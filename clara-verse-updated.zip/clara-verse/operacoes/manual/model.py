from datetime import datetime
import uuid

class OrdemManual:
    def __init__(self, ativo, tipo_ordem, quantidade, preco, usuario):
        self.id = str(uuid.uuid4())[:8]
        self.ativo = ativo.upper()
        self.tipo_ordem = tipo_ordem  # compra ou venda
        self.quantidade = float(quantidade)
        self.preco = float(preco)
        self.usuario = usuario
        self.status = "pendente"
        self.data_ordem = datetime.now()

    def executar(self):
        self.status = "executada"

    def cancelar(self):
        self.status = "cancelada"

    def to_dict(self):
        return {
            "id": self.id,
            "ativo": self.ativo,
            "tipo_ordem": self.tipo_ordem,
            "quantidade": self.quantidade,
            "preco": self.preco,
            "usuario": self.usuario,
            "status": self.status,
            "data_ordem": self.data_ordem.isoformat()
        }