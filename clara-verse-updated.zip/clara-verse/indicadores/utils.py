def calcular_indicadores(nome):
    # Simulação dos cálculos
    return {
        "indicador": nome,
        "valor": round(50 + hash(nome) % 50, 2),
        "interpretação": interpretar(nome),
        "tendência": "Alta" if hash(nome) % 2 == 0 else "Baixa"
    }

def interpretar(nome):
    explicacoes = {
        "RSI": "RSI acima de 70 indica sobrecompra; abaixo de 30, sobrevenda.",
        "MACD": "MACD positivo indica tendência de alta.",
        "Média Móvel Simples": "Ajuda a suavizar o preço, ideal para identificar tendência.",
        "Média Móvel Exponencial": "Mais sensível a preços recentes.",
        "Bollinger Bands": "Bandas estreitas indicam baixa volatilidade.",
        "Estocástico": "Ajuda a prever reversões.",
        "Volume": "Confirma força da tendência.",
        "Índice de Força Relativa": "Similar ao RSI.",
        "ADX": "Indica a força da tendência.",
        "OBV": "Indica movimentação com base no volume.",
        "Momentum": "Mede a velocidade de movimento de preços.",
        "ATR": "Mede a volatilidade média dos preços.",
    }
    return explicacoes.get(nome, "Interpretação não disponível.")

def comparar_indicadores(ind1, ind2):
    res1 = calcular_indicadores(ind1)
    res2 = calcular_indicadores(ind2)
    return {
        "indicador1": res1,
        "indicador2": res2,
        "vencedor": ind1 if res1['valor'] > res2['valor'] else ind2
    }