from flask import Blueprint, request, render_template, redirect, url_for, flash
from .model import Anjo

anjos_bp = Blueprint('anjos', __name__)
anjos = []

@anjos_bp.route('/cadastro_anjo', methods=['GET', 'POST'])
def cadastro_anjo():
    if request.method == 'POST':
        nome = request.form['nome']
        email = request.form['email']
        mestre_usuario = request.form['mestre_usuario']
        funcao = request.form['funcao']
        permissao_total = 'permissao_total' in request.form
        comissao = float(request.form['comissao'])

        novo_anjo = Anjo(
            nome=nome,
            email=email,
            mestre_usuario=mestre_usuario,
            funcao=funcao,
            permissao_total=permissao_total,
            comissao=comissao
        )

        anjos.append(novo_anjo)
        flash(f"Anjo {nome} cadastrado com sucesso!", "sucesso")
        return redirect(url_for('anjos.lista_anjos'))

    return render_template('registro/cadastro_anjo.html')

@anjos_bp.route('/anjos')
def lista_anjos():
    return render_template('registro/lista_anjos.html', anjos=[a.to_dict() for a in anjos])