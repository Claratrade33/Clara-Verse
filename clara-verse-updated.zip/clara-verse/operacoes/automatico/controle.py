from .executor import executar_ordem_automatica
from datetime import datetime

log_execucoes = []

def iniciar_ciclo(dados_mercado, ativo="BTCUSDT"):
    """
    Inicia o ciclo automático com base nos dados recebidos.
    """
    resultado = executar_ordem_automatica(ativo, dados_mercado)

    log = {
        "horario": datetime.now().isoformat(),
        "ativo": ativo,
        "resultado": resultado if resultado else "Nenhuma ordem executada"
    }

    log_execucoes.append(log)
    return log