from flask import Blueprint, render_template, request, redirect, url_for, flash
from .model import resgates_db
from .utils import calcular_elegibilidade

resgates_bp = Blueprint('resgates', __name__)

@resgates_bp.route('/resgates')
def painel_resgates():
    return render_template('resgates/painel_resgates.html', resgates=resgates_db)

@resgates_bp.route('/resgates/novo', methods=['GET', 'POST'])
def novo_resgate():
    if request.method == 'POST':
        usuario = request.form['usuario']
        tipo = request.form['tipo']
        valor = float(request.form['valor'])

        if not calcular_elegibilidade(usuario, valor):
            flash('Você ainda não tem saldo suficiente para esse resgate.')
            return redirect(url_for('resgates.novo_resgate'))

        resgates_db.append({
            'usuario': usuario,
            'tipo': tipo,
            'valor': valor
        })
        flash('Solicitação de resgate enviada com sucesso!')
        return redirect(url_for('resgates.painel_resgates'))
    
    return render_template('resgates/novo_resgate.html')

@resgates_bp.route('/resgates/<int:resgate_id>')
def detalhe_resgate(resgate_id):
    if resgate_id < len(resgates_db):
        return render_template('resgates/detalhe_resgate.html', resgate=resgates_db[resgate_id])
    flash('Resgate não encontrado.')
    return redirect(url_for('resgates.painel_resgates'))