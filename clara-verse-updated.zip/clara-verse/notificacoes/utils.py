notificacoes = []

def gerar_notificacao(titulo, mensagem, tipo, origem, prioridade="normal"):
    from .model import Notificacao
    nova = Notificacao(titulo, mensagem, tipo, origem, prioridade)
    notificacoes.append(nova)
    return nova

def listar_notificacoes(filtro_tipo=None, filtro_status=None):
    resultado = notificacoes
    if filtro_tipo:
        resultado = [n for n in resultado if n.tipo == filtro_tipo]
    if filtro_status:
        resultado = [n for n in resultado if n.status == filtro_status]
    return resultado

def buscar_notificacao_por_id(id):
    return next((n for n in notificacoes if n.id == id), None)