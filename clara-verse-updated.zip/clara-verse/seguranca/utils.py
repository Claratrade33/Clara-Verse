import requests
from datetime import datetime
from seguranca.model import salvar_log

def verificar_status_api():
    try:
        response = requests.get("https://api.binance.com/api/v3/time", timeout=3)
        if response.status_code == 200:
            return "✅ Online"
        else:
            salvar_log("API Binance respondeu com erro.")
            return "⚠️ Instável"
    except Exception as e:
        salvar_log(f"Erro ao conectar na API Binance: {e}")
        return "❌ Offline"

def verificar_integridade_banco():
    try:
        # Exemplo de verificação de integridade (pode personalizar)
        return "✅ OK"
    except Exception as e:
        salvar_log(f"Erro na integridade do banco: {e}")
        return "❌ Erro"