# /registro/rotas.py

from flask import Blueprint, render_template, request, redirect, url_for, flash
from .model import salvar_usuario

registro_bp = Blueprint('registro', __name__)

@registro_bp.route('/cadastro', methods=['GET', 'POST'])
def cadastro_usuario():
    if request.method == 'POST':
        nome = request.form.get('nome')
        email = request.form.get('email')
        senha = request.form.get('senha')
        confirmar = request.form.get('confirmar')

        if senha != confirmar:
            flash('As senhas não coincidem.')
            return redirect(url_for('registro.cadastro_usuario'))

        sucesso = salvar_usuario(nome, email, senha)

        if sucesso:
            flash('Usuário registrado com sucesso!')
            return redirect(url_for('registro.cadastro_usuario'))
        else:
            flash('Erro ao registrar. Tente novamente.')
            return redirect(url_for('registro.cadastro_usuario'))

    return render_template('registro/cadastro_usuario.html')