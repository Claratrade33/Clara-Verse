def interpretar_perfil(token):
    if token.startswith("infinity/"):
        return {
            "nivel": "avançado",
            "modo": "operacao_completa",
            "acesso": ["ia", "relatorios", "anjo", "oraculo"]
        }
    elif token.startswith("teste/"):
        return {
            "nivel": "intermediario",
            "modo": "teste_completo",
            "acesso": ["ia", "relatorios", "configuracao"]
        }
    elif token.startswith("pre/"):
        return {
            "nivel": "inicial",
            "modo": "demo",
            "acesso": ["ia", "visualizacao"]
        }
    else:
        return {
            "nivel": "desconhecido",
            "modo": "restrito",
            "acesso": []
        }

def ajustar_comportamento(perfil):
    if perfil["modo"] == "demo":
        return "Você está em modo demonstração. Algumas funções podem estar limitadas."
    elif perfil["modo"] == "operacao_completa":
        return "Modo completo ativo. Todas as ferramentas disponíveis para você, comandante."
    elif perfil["modo"] == "teste_completo":
        return "Modo teste liberado. Teste livre com IA, relatórios e ajustes."
    return "Seu modo atual é restrito. Solicite um token válido para acesso completo."