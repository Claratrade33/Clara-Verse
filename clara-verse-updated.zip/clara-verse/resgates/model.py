# Simulação de banco de dados em memória
resgates_db = []