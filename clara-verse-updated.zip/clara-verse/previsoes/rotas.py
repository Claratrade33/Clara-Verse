from flask import Blueprint, render_template, request
from .utils import gerar_previsao, sugerir_moedas

previsoes_bp = Blueprint('previsoes', __name__)

@previsoes_bp.route('/previsoes', methods=['GET', 'POST'])
def painel_previsoes():
    sugestoes = sugerir_moedas()
    resultado = None
    if request.method == 'POST':
        moeda = request.form['moeda']
        valor = float(request.form['valor'])
        tempo = int(request.form['tempo'])
        resultado = gerar_previsao(moeda, valor, tempo)
    return render_template('previsoes/painel_previsoes.html', sugestoes=sugestoes, resultado=resultado)