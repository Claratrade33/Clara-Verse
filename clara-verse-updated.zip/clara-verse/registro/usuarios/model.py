from datetime import datetime

class Usuario:
    def __init__(self, nome_completo, nascimento, telefone, email, usuario, senha):
        self.nome_completo = nome_completo
        self.nascimento = nascimento
        self.telefone = telefone
        self.email = email
        self.usuario = usuario
        self.senha = senha
        self.data_criacao = datetime.now()
        self.token_infinity = self.gerar_token_infinity()

    def gerar_token_infinity(self):
        base = self.usuario.lower().replace(" ", "")
        return f"infinity/{base}-{str(self.data_criacao.timestamp()).replace('.', '')[:13]}"

    def to_dict(self):
        return {
            "nome_completo": self.nome_completo,
            "nascimento": self.nascimento,
            "telefone": self.telefone,
            "email": self.email,
            "usuario": self.usuario,
            "senha": self.senha,
            "data_criacao": self.data_criacao.isoformat(),
            "token_infinity": self.token_infinity
        }