from flask import Blueprint, render_template, request, redirect, url_for, flash
from datetime import datetime

oraculo_bp = Blueprint('oraculo', __name__)

# Lista simulada de mensagens (substituir por banco de dados futuramente)
mensagens_oraculo = []

@oraculo_bp.route('/oraculo/nova', methods=['GET', 'POST'])
def nova_msg():
    if request.method == 'POST':
        titulo = request.form.get('titulo')
        conteudo = request.form.get('conteudo')
        remetente = request.form.get('remetente')
        data_envio = datetime.now().strftime('%d/%m/%Y %H:%M')

        nova = {
            'titulo': titulo,
            'conteudo': conteudo,
            'remetente': remetente,
            'data_envio': data_envio
        }

        mensagens_oraculo.append(nova)
        flash('Mensagem enviada ao Oráculo com sucesso!', 'success')
        return redirect(url_for('oraculo.lista_mensagens'))

    return render_template('oraculo/nova_msg.html')


@oraculo_bp.route('/oraculo/mensagens')
def lista_mensagens():
    return render_template('oraculo/lista_mensagens.html', mensagens=mensagens_oraculo)