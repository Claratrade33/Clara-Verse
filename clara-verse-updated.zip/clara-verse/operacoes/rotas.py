from flask import Blueprint, render_template, request, jsonify
from operacoes.utils import gerar_ordem_automatica, buscar_preco_atual
from operacoes.model import OrdemOperacao

operacoes_bp = Blueprint('operacoes', __name__)
ordens_ativas = []

@operacoes_bp.route("/painel-operacoes")
def painel_operacoes():
    return render_template("operacoes/painel_operacao.html", ordens=ordens_ativas)

@operacoes_bp.route("/gerar-ordem", methods=["POST"])
def gerar_ordem():
    data = request.get_json()
    par = data.get("par")
    direcao = data.get("direcao")
    entrada = float(data.get("entrada"))
    stop = float(data.get("stop"))
    alvo = float(data.get("alvo"))
    alavancagem = int(data.get("alavancagem"))

    ordem_data = gerar_ordem_automatica(par, direcao, entrada, stop, alvo, alavancagem)
    nova_ordem = OrdemOperacao(**ordem_data)
    ordens_ativas.append(nova_ordem)

    return jsonify({"status": "ok", "ordem": nova_ordem.to_dict()})