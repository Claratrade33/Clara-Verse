from flask import Blueprint, render_template, request, redirect, url_for
from .utils import gerar_notificacao, listar_notificacoes, buscar_notificacao_por_id

notificacoes_bp = Blueprint("notificacoes", __name__)

@notificacoes_bp.route("/notificacoes")
def painel_notificacoes():
    tipo = request.args.get("tipo")
    status = request.args.get("status")
    lista = listar_notificacoes(filtro_tipo=tipo, filtro_status=status)
    return render_template("notificacoes/painel_notificacoes.html", notificacoes=lista)

@notificacoes_bp.route("/notificacoes/nova", methods=["GET", "POST"])
def nova_notificacao():
    if request.method == "POST":
        titulo = request.form["titulo"]
        mensagem = request.form["mensagem"]
        tipo = request.form["tipo"]
        origem = request.form["origem"]
        prioridade = request.form["prioridade"]
        gerar_notificacao(titulo, mensagem, tipo, origem, prioridade)
        return redirect(url_for("notificacoes.painel_notificacoes"))
    return render_template("notificacoes/nova_notificacao.html")

@notificacoes_bp.route("/notificacoes/<int:id>")
def detalhe_notificacao(id):
    notificacao = buscar_notificacao_por_id(id)
    if notificacao:
        notificacao.marcar_como_lida()
        return render_template("notificacoes/detalhe_notificacao.html", notificacao=notificacao)
    return "Notificação não encontrada", 404