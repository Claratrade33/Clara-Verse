import pandas as pd
from io import BytesIO
from flask import send_file
from datetime import datetime

def exportar_dados_financeiros(dados, formato='excel'):
    df = pd.DataFrame(dados)
    nome_arquivo = f"relatorio_financeiro_{datetime.now().strftime('%Y%m%d_%H%M%S')}"

    if formato == 'pdf':
        # Exportar como PDF (requer biblioteca adicional como ReportLab, opcional)
        # Aqui vamos simplificar e apenas gerar CSV para download como fallback
        csv = df.to_csv(index=False)
        return send_file(BytesIO(csv.encode()), download_name=f"{nome_arquivo}.csv", as_attachment=True)
    
    if formato == 'excel':
        output = BytesIO()
        with pd.ExcelWriter(output, engine='xlsxwriter') as writer:
            df.to_excel(writer, index=False, sheet_name='Financeiro')
        output.seek(0)
        return send_file(output, download_name=f"{nome_arquivo}.xlsx", as_attachment=True)

def gerar_sugestoes_clarinha(saldo, despesas):
    sugestoes = []
    if saldo > 100:
        sugestoes.append("Você pode aplicar uma parte no modo automático de operação.")
    if saldo > 300:
        sugestoes.append("Considere separar uma parte para o plano 'Sonho Casas' ou para investir na loja ClaraTrade.")
    if despesas > saldo:
        sugestoes.append("Reduza despesas variáveis neste mês para evitar saldo negativo.")
    if saldo < 50:
        sugestoes.append("Evite novos gastos, priorize economia.")

    return sugestoes

def verificar_alertas(saldo, gastos, limite_previsto):
    alertas = []
    if saldo < 0:
        alertas.append("⚠️ Seu saldo está negativo! Verifique sua movimentação.")
    if gastos > limite_previsto:
        alertas.append("⚠️ Seus gastos ultrapassaram o limite previsto.")
    return alertas