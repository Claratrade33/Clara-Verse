from flask import Blueprint, render_template, request, redirect, url_for, flash
from regras.model import lista_regras, salvar_regra, obter_regra_por_id, excluir_regra
from regras.utils import validar_regra

regras_bp = Blueprint('regras', __name__)

@regras_bp.route('/regras')
def painel_regras():
    return render_template('regras/painel_regras.html', regras=lista_regras())

@regras_bp.route('/regras/nova', methods=['GET', 'POST'])
def nova_regra():
    if request.method == 'POST':
        nome = request.form['nome']
        condicao = request.form['condicao']
        acao = request.form['acao']

        if not validar_regra(nome, condicao, acao):
            flash("Todos os campos são obrigatórios.", "erro")
            return redirect(url_for('regras.nova_regra'))

        salvar_regra(nome, condicao, acao)
        flash("Regra criada com sucesso!", "sucesso")
        return redirect(url_for('regras.painel_regras'))

    return render_template('regras/nova_regra.html')

@regras_bp.route('/regras/<int:regra_id>')
def detalhe_regra(regra_id):
    regra = obter_regra_por_id(regra_id)
    if not regra:
        flash("Regra não encontrada.", "erro")
        return redirect(url_for('regras.painel_regras'))

    return render_template('regras/detalhe_regra.html', regra=regra)

@regras_bp.route('/regras/<int:regra_id>/excluir')
def excluir_regra_view(regra_id):
    excluir_regra(regra_id)
    flash("Regra excluída com sucesso.", "sucesso")
    return redirect(url_for('regras.painel_regras'))