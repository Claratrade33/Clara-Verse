import psutil
import datetime

def verificar_memoria():
    mem = psutil.virtual_memory()
    return {
        "total": mem.total,
        "usado": mem.used,
        "percentual": mem.percent
    }

def log_requisicoes_externas():
    return [
        {"url": "https://api.binance.com", "resposta": "200 OK", "data": datetime.datetime.now()},
        {"url": "https://api.openai.com", "resposta": "200 OK", "data": datetime.datetime.now()}
    ]