import psutil
import time

def obter_status_sistema():
    return {
        "cpu_percent": psutil.cpu_percent(),
        "memoria": psutil.virtual_memory()._asdict(),
        "disco": psutil.disk_usage('/')._asdict(),
        "tempo_ativo": time.time() - psutil.boot_time()
    }

def listar_tokens_ativos():
    return [
        {"id": "token_demo_123", "tipo": "DEMO", "status": "Ativo"},
        {"id": "token_teste_456", "tipo": "TESTE", "status": "Ativo"}
    ]

def desempenho_bots():
    return [
        {"nome": "BotOraculo", "status": "Rodando", "latencia": "54ms"},
        {"nome": "BotInfinity", "status": "Parado", "latencia": "N/A"}
    ]