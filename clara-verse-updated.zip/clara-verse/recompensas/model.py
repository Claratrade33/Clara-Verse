# Simulação de base de dados em memória
recompensas = []

def listar_recompensas():
    return recompensas

def adicionar_recompensa(titulo, descricao, pontos):
    recompensa = {
        'titulo': titulo,
        'descricao': descricao,
        'pontos': pontos
    }
    recompensas.append(recompensa)