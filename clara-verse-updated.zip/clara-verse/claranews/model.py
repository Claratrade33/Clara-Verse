from datetime import datetime
import uuid

class Noticia:
    def __init__(self, titulo, origem, conteudo, autor):
        self.id = str(uuid.uuid4())[:8]
        self.titulo = titulo
        self.origem = origem  # Ex: Binance, Clarinha, Manual, API
        self.conteudo = conteudo
        self.autor = autor  # Usuário ou sistema que publicou
        self.data = datetime.now()

    def to_dict(self):
        return {
            "id": self.id,
            "titulo": self.titulo,
            "origem": self.origem,
            "conteudo": self.conteudo,
            "autor": self.autor,
            "data": self.data.strftime('%d/%m/%Y %H:%M')
        }