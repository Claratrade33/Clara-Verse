from datetime import datetime
from .estrategia import analisar_entrada
from ..manual.model import OrdemManual

ordens_executadas = []

def executar_ordem_automatica(ativo, dados_mercado, usuario="clarinha-auto"):
    """
    Recebe os dados de mercado e executa ordem automática se houver sinal de entrada.
    """
    sinal = analisar_entrada(dados_mercado)

    if not sinal:
        return None  # sem sinal, sem execução

    nova_ordem = OrdemManual(
        ativo=ativo,
        tipo_ordem=sinal["tipo"],
        quantidade=sinal["quantidade"],
        preco=sinal["preco"],
        usuario=usuario
    )
    nova_ordem.executar()
    ordens_executadas.append(nova_ordem)

    return nova_ordem.to_dict()