from flask import Blueprint, render_template, request, jsonify
from inteligencia.nucleo import processar_comando
from inteligencia.memoria import registrar_interacao

inteligencia_bp = Blueprint('inteligencia', __name__)

@inteligencia_bp.route('/inteligencia', methods=['GET', 'POST'])
def painel_inteligencia():
    resposta = None
    if request.method == 'POST':
        comando = request.form.get('comando')
        if comando:
            resposta = processar_comando(comando)
            registrar_interacao(comando, resposta)
    return render_template('inteligencia/painel_inteligencia.html', resposta=resposta)

@inteligencia_bp.route('/inteligencia/api', methods=['POST'])
def api_inteligente():
    data = request.get_json()
    comando = data.get('comando')
    if comando:
        resposta = processar_comando(comando)
        registrar_interacao(comando, resposta)
        return jsonify({'resposta': resposta})
    return jsonify({'erro': 'Comando inválido'}), 400