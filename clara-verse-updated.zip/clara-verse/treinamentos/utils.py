import uuid

def gerar_id_unico():
    return str(uuid.uuid4())

def avaliar_usuario(treinamento_id, respostas):
    acertos = sum(1 for r in respostas.values() if r.lower() == 'certo')
    total = len(respostas)
    nota = round((acertos / total) * 10, 2) if total > 0 else 0

    if nota >= 8:
        mensagem = "Excelente! Você está pronto para avançar."
    elif nota >= 5:
        mensagem = "Bom! Mas ainda pode melhorar."
    else:
        mensagem = "É importante revisar o conteúdo e tentar novamente."

    return {
        "nota": nota,
        "mensagem": mensagem
    }