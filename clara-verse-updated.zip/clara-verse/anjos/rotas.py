from flask import Blueprint, render_template, request, redirect, url_for, flash
from datetime import datetime

anjos_bp = Blueprint('anjos', __name__)

# Lista simulada para armazenar os Anjos
lista_anjos = []

@anjos_bp.route('/anjos/criar', methods=['GET', 'POST'])
def criar_anjo():
    if request.method == 'POST':
        nome = request.form.get('nome')
        habilidade = request.form.get('habilidade')
        funcao = request.form.get('funcao')
        data_criacao = datetime.now().strftime('%d/%m/%Y %H:%M')

        novo_anjo = {
            'nome': nome,
            'habilidade': habilidade,
            'funcao': funcao,
            'data_criacao': data_criacao
        }

        lista_anjos.append(novo_anjo)
        flash('Anjo criado com sucesso!', 'success')
        return redirect(url_for('anjos.lista_anjos'))

    return render_template('anjos/criar_anjo.html')


@anjos_bp.route('/anjos/lista')
def lista_anjos():
    return render_template('anjos/lista_anjos.html', anjos=lista_anjos)