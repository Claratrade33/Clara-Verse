from flask import Blueprint, render_template

sinais_bp = Blueprint('sinais', __name__)

@sinais_bp.route('/sinais')
def painel_sinais():
    return render_template('sinais/painel_sinais.html')