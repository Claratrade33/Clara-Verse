from datetime import datetime

class OrdemOperacao:
    def __init__(self, par, tipo, entrada, alvo, stop, alavancagem):
        self.id = f"ordem-{datetime.now().timestamp()}"
        self.par = par
        self.tipo = tipo
        self.entrada = entrada
        self.alvo = alvo
        self.stop = stop
        self.alavancagem = alavancagem
        self.status = "Pendente"
        self.data = datetime.now().strftime("%d/%m/%Y %H:%M")

    def to_dict(self):
        return {
            "id": self.id,
            "par": self.par,
            "tipo": self.tipo,
            "entrada": self.entrada,
            "alvo": self.alvo,
            "stop": self.stop,
            "alavancagem": self.alavancagem,
            "status": self.status,
            "data": self.data
        }