from flask import Blueprint, render_template

estatisticas_bp = Blueprint('estatisticas', __name__)

@estatisticas_bp.route('/painel-estatisticas')
def painel_estatisticas():
    # Exemplo de dados fictícios (substituir por dados reais depois)
    dados = {
        'usuarios': 158,
        'sinais_emitidos': 732,
        'operacoes_executadas': 489,
        'lucro_total': 12750.35,
        'anjos_ativos': 14,
        'tokens_ativos': 61
    }
    return render_template('estatisticas/painel_estatisticas.html', dados=dados)