from flask import Blueprint, render_template, request, redirect, url_for, flash
from .model import listar_clientes, salvar_cliente

clientes_bp = Blueprint('clientes', __name__)

@clientes_bp.route('/clientes')
def painel_clientes():
    lista = listar_clientes()
    return render_template('clientes/painel_clientes.html', clientes=lista)

@clientes_bp.route('/clientes/novo', methods=['POST'])
def novo_cliente():
    nome = request.form.get('nome')
    email = request.form.get('email')
    plano = request.form.get('plano')
    token = request.form.get('token')

    if not nome or not email:
        flash("Preencha todos os campos obrigatórios.")
        return redirect(url_for('clientes.painel_clientes'))

    salvar_cliente(nome, email, plano, token)
    flash("Cliente cadastrado com sucesso!")
    return redirect(url_for('clientes.painel_clientes'))