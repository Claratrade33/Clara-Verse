# Função de elegibilidade fictícia baseada em regra de saldo mínimo
def calcular_elegibilidade(usuario, valor):
    # Exemplo fixo - ajustar com dados reais depois
    saldo_disponivel = 500  # Substituir pelo real da conta
    return valor <= saldo_disponivel