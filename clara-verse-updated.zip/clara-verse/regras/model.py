# Simulação de banco de dados em memória
regras_db = []

def lista_regras():
    return regras_db

def salvar_regra(nome, condicao, acao):
    nova_regra = {
        "id": len(regras_db) + 1,
        "nome": nome,
        "condicao": condicao,
        "acao": acao
    }
    regras_db.append(nova_regra)

def obter_regra_por_id(regra_id):
    for regra in regras_db:
        if regra['id'] == regra_id:
            return regra
    return None

def excluir_regra(regra_id):
    global regras_db
    regras_db = [r for r in regras_db if r['id'] != regra_id]