from flask import Blueprint, render_template

guardian_bp = Blueprint('guardian', __name__)

# Rota principal do painel do Guardian
@guardian_bp.route('/guardian/painel')
def painel_guardian():
    return render_template('guardian/painel_guardian.html')

# Rota para visualizar os logs do Guardian
@guardian_bp.route('/guardian/logs')
def logs_guardian():
    # Exemplo estático de logs (deve ser substituído por registros reais futuramente)
    logs = [
        {"data": "2025-07-12 10:00", "mensagem": "Monitoramento iniciado."},
        {"data": "2025-07-12 10:05", "mensagem": "Sinal de reversão identificado."},
        {"data": "2025-07-12 10:10", "mensagem": "Stop Loss ajustado automaticamente."}
    ]
    return render_template('guardian/log_guardian.html', logs=logs)