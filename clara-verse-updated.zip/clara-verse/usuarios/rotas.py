from flask import Blueprint, render_template, request, redirect, url_for, flash

usuarios_bp = Blueprint('usuarios', __name__, template_folder='../templates/usuarios')

# Simulando banco de dados em memória
usuarios = []

@usuarios_bp.route('/usuarios')
def listar_usuarios():
    return render_template('usuarios/listar_usuarios.html', usuarios=usuarios)

@usuarios_bp.route('/usuarios/novo', methods=['GET', 'POST'])
def novo_usuario():
    if request.method == 'POST':
        nome = request.form['nome']
        email = request.form['email']
        usuario = request.form['usuario']
        senha = request.form['senha']

        usuarios.append({
            'nome': nome,
            'email': email,
            'usuario': usuario,
            'senha': senha
        })

        flash('Usuário cadastrado com sucesso!')
        return redirect(url_for('usuarios.listar_usuarios'))

    return render_template('usuarios/novo_usuario.html')