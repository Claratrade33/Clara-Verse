from flask import Blueprint, render_template
from seguranca.utils import verificar_status_api, verificar_integridade_banco
from seguranca.model import log_evento

seguranca_bp = Blueprint('seguranca', __name__)

@seguranca_bp.route('/painel/seguranca')
def painel_seguranca():
    status_api = verificar_status_api()
    integridade_banco = verificar_integridade_banco()
    eventos = log_evento(limit=10)
    return render_template('seguranca/painel_seguranca.html',
                           status_api=status_api,
                           integridade_banco=integridade_banco,
                           eventos=eventos)