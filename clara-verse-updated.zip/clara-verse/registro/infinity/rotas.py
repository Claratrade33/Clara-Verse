from flask import Blueprint, request, render_template, redirect, url_for, flash
from .model import TokenInfinity

infinity_bp = Blueprint('infinity', __name__)
tokens_infinity = []

@infinity_bp.route('/gerar_token', methods=['GET', 'POST'])
def gerar_token():
    if request.method == 'POST':
        criador = request.form['criador']
        tipo = request.form['tipo']  # 'usuario' ou 'anjo'

        novo_token = TokenInfinity(criador=criador, tipo=tipo)
        tokens_infinity.append(novo_token)

        flash(f"Token Infinity criado com sucesso para {criador}!", "sucesso")
        return redirect(url_for('infinity.lista_tokens'))

    return render_template('registro/gerar_token_infinity.html')

@infinity_bp.route('/tokens_infinity')
def lista_tokens():
    return render_template('registro/lista_tokens_infinity.html', tokens=[t.to_dict() for t in tokens_infinity])