def analisar_entrada(dados_mercado):
    """
    Analisa os dados de mercado e retorna um sinal de entrada, se houver.
    Esta versão é simplificada e pode ser substituída por lógica mais avançada.
    """

    # Exemplo de estrutura esperada: {'preco_atual': 100, 'media_curta': 98, 'media_longa': 95}
    preco = dados_mercado.get("preco_atual")
    m_curta = dados_mercado.get("media_curta")
    m_longa = dados_mercado.get("media_longa")

    if not all([preco, m_curta, m_longa]):
        return None  # Dados incompletos

    # Lógica simples: entrada de compra quando há cruzamento de média curta sobre longa
    if m_curta > m_longa and preco > m_curta:
        return {
            "tipo": "compra",
            "quantidade": 10,
            "preco": preco
        }

    # Lógica de venda: quando o preço cai abaixo das médias
    if preco < m_curta and m_curta < m_longa:
        return {
            "tipo": "venda",
            "quantidade": 10,
            "preco": preco
        }

    return None  # Nenhum sinal