from conectores.binance import obter_cliente_binance
from operacoes_automatico.inteligencia import gerar_ordem_automatizada

def executar_ordens_automaticas(usuarios_com_config):
    for usuario in usuarios_com_config:
        chave_api = usuario['api_key']
        chave_secreta = usuario['api_secret']

        cliente = obter_cliente_binance(chave_api, chave_secreta)
        if not cliente:
            print(f"[ERRO] Não foi possível conectar com Binance para {usuario['usuario']}")
            continue

        ordem = gerar_ordem_automatizada(usuario)
        if ordem:
            try:
                cliente.create_order(
                    symbol=ordem['par'],
                    side=ordem['tipo'],
                    type="MARKET",
                    quantity=ordem['quantidade']
                )
                print(f"[EXECUTADA] Ordem {ordem['tipo']} de {ordem['quantidade']} {ordem['par']} para {usuario['usuario']}")
            except Exception as e:
                print(f"[ERRO AO EXECUTAR ORDEM] {e}")