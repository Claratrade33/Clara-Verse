from flask import Blueprint, render_template, request, redirect, url_for, flash
from .model import obter_treinamentos, salvar_treinamento, obter_treinamento_por_id
from .utils import gerar_id_unico, avaliar_usuario

treinamentos_bp = Blueprint('treinamentos', __name__, template_folder='templates')

@treinamentos_bp.route('/treinamentos')
def painel_treinamentos():
    lista = obter_treinamentos()
    return render_template('treinamentos/painel_treinamentos.html', treinamentos=lista)

@treinamentos_bp.route('/treinamentos/novo', methods=['GET', 'POST'])
def novo_treinamento():
    if request.method == 'POST':
        dados = {
            'id': gerar_id_unico(),
            'titulo': request.form['titulo'],
            'descricao': request.form['descricao'],
            'nivel': request.form['nivel'],
            'conteudo': request.form['conteudo']
        }
        salvar_treinamento(dados)
        flash('Treinamento criado com sucesso!', 'success')
        return redirect(url_for('treinamentos.painel_treinamentos'))
    return render_template('treinamentos/novo_treinamento.html')

@treinamentos_bp.route('/treinamentos/<id>')
def detalhe_treinamento(id):
    treinamento = obter_treinamento_por_id(id)
    return render_template('treinamentos/detalhe_treinamento.html', treinamento=treinamento)

@treinamentos_bp.route('/treinamentos/<id>/avaliar', methods=['GET', 'POST'])
def avaliacao_treinamento(id):
    if request.method == 'POST':
        respostas = request.form.to_dict()
        resultado = avaliar_usuario(id, respostas)
        flash(f'Sua nota foi: {resultado["nota"]} - {resultado["mensagem"]}', 'info')
        return redirect(url_for('treinamentos.painel_treinamentos'))
    return render_template('treinamentos/avaliacao_treinamento.html', treinamento_id=id)