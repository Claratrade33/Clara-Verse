from feedbacks.model import Feedback

_feedbacks_db = []
_id_counter = 1

def salvar_feedback(usuario, tipo, mensagem, token):
    global _id_counter
    feedback = Feedback(
        id=_id_counter,
        usuario=usuario,
        tipo=tipo,
        mensagem=mensagem,
        token=token
    )
    _feedbacks_db.append(feedback)
    _id_counter += 1

def listar_feedbacks():
    return list(reversed(_feedbacks_db))

def buscar_feedback_por_id(id):
    for f in _feedbacks_db:
        if f.id == id:
            return f
    return None