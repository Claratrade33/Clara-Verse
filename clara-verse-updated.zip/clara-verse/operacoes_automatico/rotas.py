from flask import Blueprint, render_template, request, redirect
from operacoes_automatico.leitura_mercado import obter_dados_mercado
from operacoes_automatico.inteligencia import executar_estrategia

operacoes_automatico_bp = Blueprint('operacoes_automatico', __name__, template_folder='../templates/operacoes_automatico')

@operacoes_automatico_bp.route('/painel_automatico')
def painel_automatico():
    labels, dados = obter_dados_mercado('BTCUSDT')
    estrategia = "Infinity Strike V2"
    ultima_acao = "Compra em suporte"
    status = "Ativa"
    resultado = "+2.8%"

    return render_template('operacoes_automatico/painel_automatico.html',
                           labels=labels, dados=dados,
                           estrategia=estrategia,
                           ultima_acao=ultima_acao,
                           status=status,
                           resultado=resultado)

@operacoes_automatico_bp.route('/operacoes_automatico/ativar', methods=['POST'])
def ativar_estrategia():
    executar_estrategia()
    return redirect('/painel_automatico')