from flask import Blueprint, render_template, request, redirect, url_for, flash
from werkzeug.utils import secure_filename
import os
from datetime import datetime

from documentos.model import documentos_db
from documentos.utils import salvar_arquivo

documentos_bp = Blueprint('documentos', __name__, template_folder='../templates/documentos')

@documentos_bp.route('/documentos')
def painel_documentos():
    return render_template('documentos/painel_documentos.html', documentos=documentos_db)

@documentos_bp.route('/documentos/novo', methods=['GET', 'POST'])
def novo_documento():
    if request.method == 'POST':
        nome = request.form['nome']
        tipo = request.form['tipo']
        arquivo = request.files['arquivo']

        if arquivo:
            nome_arquivo = secure_filename(arquivo.filename)
            caminho = salvar_arquivo(arquivo, nome_arquivo)
            data_envio = datetime.now().strftime('%d/%m/%Y %H:%M')

            novo = {
                'id': len(documentos_db) + 1,
                'nome': nome,
                'tipo': tipo,
                'arquivo': nome_arquivo,
                'data_envio': data_envio,
                'caminho': caminho
            }
            documentos_db.append(novo)
            flash('Documento enviado com sucesso!', 'success')
            return redirect(url_for('documentos.painel_documentos'))

    return render_template('documentos/novo_documento.html')

@documentos_bp.route('/documentos/<int:id>')
def detalhe_documento(id):
    doc = next((d for d in documentos_db if d['id'] == id), None)
    if not doc:
        flash('Documento não encontrado.', 'danger')
        return redirect(url_for('documentos.painel_documentos'))
    return render_template('documentos/detalhe_documento.html', documento=doc)