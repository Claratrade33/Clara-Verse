def calcular_estatisticas(operacoes):
    total_operacoes = len(operacoes)
    total_ganho = 0
    total_perda = 0
    operacoes_ativas = 0
    encerradas = 0

    for op in operacoes:
        if op["status"] == "aberta":
            operacoes_ativas += 1
        else:
            encerradas += 1
            resultado = float(op["alvo"]) - float(op["valor_entrada"]) if op["tipo"] == "compra" else float(op["valor_entrada"]) - float(op["stop"])
            if resultado > 0:
                total_ganho += resultado
            else:
                total_perda += abs(resultado)

    taxa_acerto = (total_ganho / (total_ganho + total_perda) * 100) if (total_ganho + total_perda) > 0 else 0

    return {
        "total_operacoes": total_operacoes,
        "encerradas": encerradas,
        "ativas": operacoes_ativas,
        "ganhos": round(total_ganho, 2),
        "perdas": round(total_perda, 2),
        "taxa_acerto": round(taxa_acerto, 2)
    }