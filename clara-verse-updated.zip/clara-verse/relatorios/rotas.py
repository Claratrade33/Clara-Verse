from flask import Blueprint, render_template
from .analise import calcular_estatisticas

relatorios_bp = Blueprint('relatorios', __name__)

# Simulação temporária de dados (substituir futuramente por banco de dados real)
operacoes_exemplo = [
    {"tipo": "compra", "valor_entrada": 100.0, "alvo": 110.0, "stop": 95.0, "status": "encerrada"},
    {"tipo": "venda", "valor_entrada": 120.0, "alvo": 110.0, "stop": 125.0, "status": "encerrada"},
    {"tipo": "compra", "valor_entrada": 150.0, "alvo": 160.0, "stop": 140.0, "status": "aberta"}
]

@relatorios_bp.route('/relatorio_geral')
def relatorio_geral():
    estatisticas = calcular_estatisticas(operacoes_exemplo)
    return render_template('relatorios/relatorio_geral.html', estatisticas=estatisticas)