from datetime import datetime

class Notificacao:
    def __init__(self, titulo, mensagem, tipo, origem, prioridade="normal", status="não lida"):
        self.id = id(self)
        self.titulo = titulo
        self.mensagem = mensagem
        self.tipo = tipo  # Ex: alerta, sistema, operação
        self.origem = origem  # Ex: guardian, oraculo
        self.prioridade = prioridade  # normal, alta, crítica
        self.status = status  # não lida, lida, arquivada
        self.data = datetime.now()

    def marcar_como_lida(self):
        self.status = "lida"

    def arquivar(self):
        self.status = "arquivada"