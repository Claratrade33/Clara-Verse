import datetime

# Simulação de histórico (substituir por banco de dados real)
dados_historico = [
    {
        "data": "2025-07-10 09:00",
        "tipo": "Login",
        "usuario": "comandante",
        "descricao": "Acesso ao painel de controle"
    },
    {
        "data": "2025-07-11 15:23",
        "tipo": "Operação",
        "usuario": "comandante",
        "descricao": "Ordem de compra executada em BTC/USDT"
    },
    {
        "data": "2025-07-12 17:02",
        "tipo": "Configuração",
        "usuario": "comandante",
        "descricao": "Alteração no modo de operação (Demo → Real)"
    },
]

def obter_historico_completo():
    return sorted(dados_historico, key=lambda x: x["data"], reverse=True)