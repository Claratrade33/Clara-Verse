# monitor.py

import time

def acompanhar_ordens(ativo, client, ordem_id):
    """
    Verifica em loop o status da ordem até execução ou timeout.
    """
    timeout = time.time() + 60  # 1 minuto
    while time.time() < timeout:
        status = client.checar_ordem(ativo, ordem_id)
        if status == 'executada':
            return True
        time.sleep(3)
    return False