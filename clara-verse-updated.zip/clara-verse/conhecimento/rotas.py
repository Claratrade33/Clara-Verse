from flask import Blueprint, render_template

conhecimento_bp = Blueprint('conhecimento', __name__)

@conhecimento_bp.route('/conhecimento')
def painel_conhecimento():
    return render_template('conhecimento/painel_conhecimento.html')

@conhecimento_bp.route('/conhecimento/escola')
def escola_claraverse():
    return render_template('conhecimento/escola_claraverse.html')