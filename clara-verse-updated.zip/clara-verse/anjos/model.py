from datetime import datetime
import uuid

class Anjo:
    def __init__(self, nome, nivel, simbolo, descricao):
        self.id = str(uuid.uuid4())[:8]
        self.nome = nome
        self.nivel = nivel  # Ex: guardiao, mentor, observador
        self.simbolo = simbolo  # Ex: uma runa, um token, uma sigla
        self.descricao = descricao
        self.data_registro = datetime.now()

    def to_dict(self):
        return {
            "id": self.id,
            "nome": self.nome,
            "nivel": self.nivel,
            "simbolo": self.simbolo,
            "descricao": self.descricao,
            "data_registro": self.data_registro.strftime('%d/%m/%Y %H:%M')
        }