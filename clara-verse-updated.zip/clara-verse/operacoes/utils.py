import requests
import os
from binance.client import Client
from dotenv import load_dotenv

load_dotenv()

API_KEY = os.getenv("BINANCE_API_KEY")
API_SECRET = os.getenv("BINANCE_API_SECRET")

client = Client(API_KEY, API_SECRET)

def buscar_preco_atual(par_moeda):
    try:
        ticker = client.get_symbol_ticker(symbol=par_moeda)
        return float(ticker['price'])
    except Exception as e:
        print(f"Erro ao buscar preço: {e}")
        return None

def gerar_ordem_automatica(par, direcao, entrada, stop, alvo, alavancagem):
    return {
        "par": par,
        "tipo": "LONG" if direcao == "compra" else "SHORT",
        "entrada": entrada,
        "stop": stop,
        "alvo": alvo,
        "alavancagem": alavancagem
    }

def calcular_entrada_porcentagem(preco_atual, percentual):
    return round(preco_atual * (1 + percentual / 100), 2)