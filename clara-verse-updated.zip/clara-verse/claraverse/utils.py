def gerar_plano_claraverse(sonho_usuario):
    if not sonho_usuario:
        return "Por favor, descreva seu sonho para que a Clarinha possa te orientar."

    plano_base = f"""
    <h3>Plano Estratégico ClaraVerse para: {sonho_usuario}</h3>
    <ul>
        <li><b>1. Diagnóstico:</b> A Clarinha vai te perguntar o que você já tem hoje (renda, reservas, bens).</li>
        <li><b>2. Projeção:</b> Vamos estimar quanto você precisa, quanto pode separar por mês e o prazo.</li>
        <li><b>3. Caminhos:</b> A plataforma pode te ajudar de três formas:
            <ul>
                <li>💸 Operações automáticas (modo trader com proteção de banca).</li>
                <li>📦 Vendas dos produtos da Loja Clara com apoio de marketing.</li>
                <li>📈 Investimentos inteligentes com metas claras.</li>
            </ul>
        </li>
        <li><b>4. Renda crescente:</b> Com lucros reinvestidos ou novos produtos vendidos, seu plano evolui mês a mês.</li>
        <li><b>5. Clareza emocional:</b> Você terá apoio psicológico, ético e prático com as Pegadas do Cerrado.</li>
    </ul>
    <p><b>Pronto para começar? A Clarinha está com você!</b></p>
    """

    return plano_base