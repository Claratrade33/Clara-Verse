from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from .model import Configuracao

configuracao_bp = Blueprint('configuracao', __name__)

# Configuração padrão da nave (modo demo)
config_atual = Configuracao(
    modo_operacao="demo",
    estrategia="IA híbrida",
    intervalo_candle="5m",
    risco_percentual=1.0
)

@configuracao_bp.route('/painel_configuracao', methods=['GET', 'POST'])
def painel_configuracao():
    token_tipo = session.get("tipo_token", "pre-inauguracao")  # ou 'teste', etc.
    pode_alterar = token_tipo == "teste"

    if request.method == 'POST':
        if not pode_alterar:
            flash("Este painel está em modo demonstração. Você não tem permissão para alterar as configurações.", "erro")
            return redirect(url_for('configuracao.painel_configuracao'))

        # Alerta ao tentar alterar estando em token de teste
        flash("Você está utilizando um token de usuário de teste. Deseja realmente continuar?", "aviso")

        config_atual.modo_operacao = request.form['modo_operacao']
        config_atual.estrategia = request.form['estrategia']
        config_atual.intervalo_candle = request.form['intervalo_candle']
        config_atual.risco_percentual = float(request.form['risco_percentual'])
        config_atual.api_binance = request.form.get('api_binance')
        config_atual.api_openai = request.form.get('api_openai')

        flash("Configurações atualizadas com sucesso!", "sucesso")
        return redirect(url_for('configuracao.painel_configuracao'))

    return render_template(
        'configuracao/painel_configuracao.html',
        config=config_atual.to_dict(),
        pode_alterar=pode_alterar
    )