from flask import Blueprint, render_template, request
from recursos.utils import calcular_resultado, converter_valor

recursos_bp = Blueprint('recursos', __name__)

@recursos_bp.route('/recursos/calculadora', methods=['GET', 'POST'])
def calculadora():
    resultado = None
    if request.method == 'POST':
        valor1 = float(request.form['valor1'])
        valor2 = float(request.form['valor2'])
        operacao = request.form['operacao']
        resultado = calcular_resultado(valor1, valor2, operacao)
    return render_template('recursos/calculadora.html', resultado=resultado)

@recursos_bp.route('/recursos/conversor', methods=['GET', 'POST'])
def conversor():
    resultado = None
    if request.method == 'POST':
        valor = float(request.form['valor'])
        tipo = request.form['tipo']
        resultado = converter_valor(valor, tipo)
    return render_template('recursos/conversor.html', resultado=resultado)