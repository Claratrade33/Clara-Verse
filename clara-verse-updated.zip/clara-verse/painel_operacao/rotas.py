from flask import Blueprint, render_template, request
from conectores.binance import obter_cliente_binance
from monitoramento.graficos import obter_dados_grafico
import os
from dotenv import load_dotenv

load_dotenv()

painel_execucao_bp = Blueprint('painel_execucao', __name__)

@painel_execucao_bp.route('/painel_execucao')
def painel_execucao():
    labels, dados = obter_dados_grafico('BTCUSDT')
    return render_template('operacoes/painel_execucao.html', labels=labels, dados=dados)

@painel_execucao_bp.route('/executar_ordem_manual', methods=['POST'])
def executar_ordem_manual():
    par = request.form['par']
    quantidade = float(request.form['quantidade'])
    tipo = request.form['tipo']

    chave = os.getenv("BINANCE_API_KEY")
    segredo = os.getenv("BINANCE_API_SECRET")

    cliente = obter_cliente_binance(chave, segredo)
    try:
        cliente.create_order(
            symbol=par,
            side=tipo,
            type='MARKET',
            quantity=quantidade
        )
        return "Ordem executada com sucesso!"
    except Exception as e:
        return f"Erro: {e}"