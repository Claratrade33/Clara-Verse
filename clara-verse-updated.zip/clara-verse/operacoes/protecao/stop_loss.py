def definir_stop_loss(preco_entrada, percentual_perda=2.0):
    """
    Calcula o preço do stop loss com base no percentual de perda desejado.
    """
    stop_loss = preco_entrada * (1 - percentual_perda / 100)
    return round(stop_loss, 2)