from flask import Blueprint, render_template, request, redirect, url_for, flash
import datetime

estrategias_bp = Blueprint('estrategias', __name__)

# Lista simulada de estratégias (substituir futuramente por banco de dados)
estrategias = []

@estrategias_bp.route('/painel-estrategias', methods=['GET', 'POST'])
def painel_estrategias():
    if request.method == 'POST':
        nome = request.form['nome']
        descricao = request.form['descricao']
        tipo = request.form['tipo']
        data_criacao = datetime.datetime.now().strftime('%d/%m/%Y %H:%M')

        nova_estrategia = {
            'nome': nome,
            'descricao': descricao,
            'tipo': tipo,
            'data': data_criacao
        }

        estrategias.append(nova_estrategia)
        flash('Estratégia criada com sucesso!', 'success')
        return redirect(url_for('estrategias.painel_estrategias'))

    return render_template('estrategias/painel_estrategias.html', estrategias=estrategias)