"""Rotas para o módulo de inteligência financeira.

Este blueprint expõe uma rota `/analise` que permite ao usuário
solicitar uma análise de mercado para um par de criptomoedas. A
análise combina dados históricos obtidos da API pública da Binance
com um resumo gerado por um modelo de linguagem da OpenAI. As
chaves de API devem ser definidas nas variáveis de ambiente
`BINANCE_API_KEY`, `BINANCE_API_SECRET` (quando aplicável) e
`OPENAI_API_KEY`.
"""

from __future__ import annotations

import os
from flask import Blueprint, render_template, request, flash
import pandas as pd

try:
    import openai  # type: ignore
except ImportError:
    openai = None  # Aplica fallback se a biblioteca não estiver disponível

from operacoes_automatico.leitura_mercado import obter_dados_binance
from .utils import df_to_markdown_table


inteligencia_bp = Blueprint(
    'inteligencia_financeira',
    __name__,
    template_folder='../templates/inteligencia_financeira'
)


@inteligencia_bp.route('/analise', methods=['GET', 'POST'])
def analise():
    """Página que apresenta um formulário para solicitar análises e exibe resultados.

    Quando acessada via GET, renderiza o formulário. Quando via POST,
    coleta os parâmetros, busca os dados da Binance e solicita ao
    modelo da OpenAI uma análise textual. Em caso de erro, uma
    mensagem de alerta é exibida no topo da página.
    """
    resultado: str | None = None
    if request.method == 'POST':
        symbol = request.form.get('symbol', 'BTCUSDT').upper()
        interval = request.form.get('interval', '1h')
        try:
            limit = int(request.form.get('limit', '100'))
        except ValueError:
            limit = 100

        # Busca os dados de mercado
        try:
            df = obter_dados_binance(symbol=symbol, interval=interval, limit=limit)
            if df.empty:
                flash('Não foi possível obter dados de mercado para o par informado.', 'erro')
                return render_template('inteligencia_financeira/analise.html', resultado=None)
        except Exception as exc:
            flash(f'Erro ao obter dados da Binance: {exc}', 'erro')
            return render_template('inteligencia_financeira/analise.html', resultado=None)

        # Gera tabela Markdown a partir dos dados
        markdown_table = df_to_markdown_table(df)

        # Solicita análise ao modelo da OpenAI
        api_key = os.getenv('OPENAI_API_KEY')
        if not api_key:
            flash('A chave da OpenAI não está configurada no ambiente.', 'erro')
            return render_template('inteligencia_financeira/analise.html', resultado=None)

        if openai is None:
            flash('A biblioteca openai não está instalada.', 'erro')
            return render_template('inteligencia_financeira/analise.html', resultado=None)

        # Configura chave
        openai.api_key = api_key
        prompt_usuario = (
            f"A seguir está uma tabela com os preços de fechamento recentes para o par {symbol} "
            f"no intervalo {interval}.\n"
            f"{markdown_table}\n\n"
            "Analise as tendências e forneça um resumo em português com possíveis "
            "cenários de curto prazo."
        )
        try:
            # Usa a API de completions de chat para gerar texto
            response = openai.ChatCompletion.create(
                model='gpt-3.5-turbo',
                messages=[{"role": "user", "content": prompt_usuario}],
                max_tokens=300,
                temperature=0.7
            )
            resumo = response.choices[0].message['content'].strip()
        except Exception as exc:
            resumo = f"Erro ao gerar análise: {exc}"

        resultado = resumo

    return render_template('inteligencia_financeira/analise.html', resultado=resultado)