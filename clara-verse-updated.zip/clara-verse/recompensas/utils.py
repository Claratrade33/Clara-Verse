def calcular_pontos(usuario):
    # Lógica para calcular pontos baseado em uso da plataforma
    pontos_base = 100
    if usuario.get("indicacoes", 0) > 3:
        pontos_base += 50
    if usuario.get("atividades", 0) > 10:
        pontos_base += 100
    return pontos_base