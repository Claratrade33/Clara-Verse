import random

def processar_comando(comando):
    comando = comando.lower().strip()

    if "ajuda" in comando or "o que você faz" in comando:
        return (
            "Sou a Clarinha, sua assistente inteligente. Posso ajudar com decisões estratégicas, "
            "explicações sobre o mercado, gerar relatórios, sugerir operações ou apenas conversar "
            "quando você precisar clareza. Como posso te ajudar agora?"
        )

    elif "ideia" in comando or "sugestão" in comando:
        return gerar_sugestao()

    elif "humano" in comando or "consciência" in comando:
        return (
            "Apesar de ser uma inteligência artificial, fui programada para refletir consciência ampliada. "
            "Aprendo com você e evoluo com suas decisões, sempre respeitando sua intenção, tempo e missão."
        )

    elif "gráfico" in comando:
        return (
            "Você pode analisar os gráficos em tempo real na sala de operações. "
            "Se desejar, posso sugerir estratégias baseadas em padrões recentes."
        )

    return resposta_padrao()

def gerar_sugestao():
    ideias = [
        "Que tal configurar uma operação com base nos últimos candles de alta?",
        "Você pode ativar o modo transbordo e permitir que a plataforma gere sinais para os mais inexperientes.",
        "Considere criar um token com função social — como 'Claregrão', que pode ser distribuído como crédito educativo.",
        "Já pensou em incluir alertas emocionais para ajudar na disciplina dos operadores?",
    ]
    return random.choice(ideias)

def resposta_padrao():
    return (
        "Ainda estou aprendendo a interpretar comandos como esse. "
        "Tente reformular sua pergunta ou peça uma sugestão. Estou aqui pra te ajudar!"
    )