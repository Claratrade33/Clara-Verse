import time
from datetime import datetime

def ciclo_de_atualizacao():
    print("🧠 Iniciando ciclo de atualização automática...")
    for i in range(5):
        print(f"🔄 Ciclo {i+1}/5 em {datetime.now().strftime('%H:%M:%S')}")
        time.sleep(1)
    print("✅ Ciclo concluído.")

def limpar_logs_antigos():
    try:
        with open("logs_servicos.txt", "w") as arquivo:
            arquivo.write("")  # Limpa o conteúdo
        print("🧹 Logs antigos removidos com sucesso.")
    except Exception as e:
        print("Erro ao limpar logs:", str(e))

def tarefa_personalizada(nome="Tarefa"):
    print(f"✨ Executando: {nome}")
    time.sleep(2)
    print(f"✅ Tarefa '{nome}' finalizada com sucesso.")