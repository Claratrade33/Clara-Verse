from flask import Flask, render_template
from dotenv import load_dotenv
import os

# Carrega variáveis de ambiente
load_dotenv()

# Criação do app Flask
app = Flask(__name__)
app.secret_key = os.getenv("SECRET_KEY", "chave-padrao-insegura")

# Registro dos Blueprints do ClaraTrade
from painel.rotas import painel_bp
from tokens.rotas import tokens_bp
from registro.rotas import registro_bp
from usuarios.rotas import usuarios_bp
from infinity.rotas import infinity_bp
from anjos.rotas import anjos_bp
from claranews.rotas import claranews_bp
from comando.rotas import comando_bp
from clientes.rotas import clientes_bp
from vendedores.rotas import vendedores_bp
from acessos.rotas import acessos_bp
from seguranca.rotas import seguranca_bp
from monitoramento.rotas import monitoramento_bp
from feedbacks.rotas import feedbacks_bp
from previsoes.rotas import previsoes_bp
from documentos.rotas import documentos_bp
from regras.rotas import regras_bp
from indicadores.rotas import indicadores_bp
from conectores.rotas import conectores_bp
from operacoes.rotas import operacoes_bp
from sinais.rotas import sinais_bp
from financeiro.rotas import financeiro_bp
from estatisticas.rotas import estatisticas_bp
from notificacoes.rotas import notificacoes_bp
from treinamentos.rotas import treinamentos_bp
from conhecimento.rotas import conhecimento_bp
from historico.rotas import historico_bp
from inteligencia_financeira import inteligencia_bp

# Registra todos os blueprints
app.register_blueprint(painel_bp)
app.register_blueprint(tokens_bp)
app.register_blueprint(registro_bp)
app.register_blueprint(usuarios_bp)
app.register_blueprint(infinity_bp)
app.register_blueprint(anjos_bp)
app.register_blueprint(claranews_bp)
app.register_blueprint(comando_bp)
app.register_blueprint(clientes_bp)
app.register_blueprint(vendedores_bp)
app.register_blueprint(acessos_bp)
app.register_blueprint(seguranca_bp)
app.register_blueprint(monitoramento_bp)
app.register_blueprint(feedbacks_bp)
app.register_blueprint(previsoes_bp)
app.register_blueprint(documentos_bp)
app.register_blueprint(regras_bp)
app.register_blueprint(indicadores_bp)
app.register_blueprint(conectores_bp)
app.register_blueprint(operacoes_bp)
app.register_blueprint(sinais_bp)
app.register_blueprint(financeiro_bp)
app.register_blueprint(estatisticas_bp)
app.register_blueprint(notificacoes_bp)
app.register_blueprint(treinamentos_bp)
app.register_blueprint(conhecimento_bp)
app.register_blueprint(historico_bp)
app.register_blueprint(inteligencia_bp)

# Página inicial
@app.route('/')
def index():
    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)