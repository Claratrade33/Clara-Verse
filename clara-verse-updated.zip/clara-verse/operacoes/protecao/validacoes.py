def validar_configuracoes(preco_entrada, stop_loss, take_profit):
    """
    Verifica se os valores de stop e take estão bem configurados.
    """
    if stop_loss >= preco_entrada:
        return False, "Stop Loss deve ser menor que o preço de entrada."
    if take_profit <= preco_entrada:
        return False, "Take Profit deve ser maior que o preço de entrada."
    return True, "Configurações válidas."