from flask import Blueprint, render_template

rotas_publicas_bp = Blueprint('rotas_publicas', __name__)

@rotas_publicas_bp.route('/inicio')
def inicio_publico():
    return render_template('publicas/home_publica.html')

@rotas_publicas_bp.route('/faq')
def faq():
    return render_template('publicas/faq.html')

@rotas_publicas_bp.route('/termos')
def termos():
    return render_template('publicas/termos.html')