import random

def sugerir_moedas():
    return ['BTC', 'ETH', 'BNB', 'SOL', 'ADA', 'MATIC']

def gerar_previsao(moeda, valor_investido, tempo_meses):
    crescimento_mensal = random.uniform(0.02, 0.12)
    retorno_estimado = round(valor_investido * ((1 + crescimento_mensal) ** tempo_meses), 2)
    analise = f"Com base em um crescimento médio mensal de {crescimento_mensal:.2%}, seu investimento de R${valor_investido} em {moeda} poderá chegar a aproximadamente R${retorno_estimado} em {tempo_meses} meses."

    return {
        "moeda": moeda,
        "valor_investido": valor_investido,
        "tempo": tempo_meses,
        "retorno_estimado": retorno_estimado,
        "analise": analise
    }